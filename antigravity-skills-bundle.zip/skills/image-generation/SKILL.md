---
name: image-generation
description: Menghasilkan gambar ilustrasi, aset grafis, diagram arsitektur, dan mockup UI menggunakan pipeline AI dan subagent khusus image-generator.
---

# Skill: Image Generation (Menggambar & Aset Visual)

Skill ini digunakan untuk mengarahkan model AI menghasilkan gambar visual, konsep desain, atau diagram.

## Format Prompting Gambar Standar:
1. **Subject**: Deskripsi objek utama secara spesifik (misal: "Sleek pharmacy medicine packaging with modern barcode label").
2. **Style**: Gaya visual (e.g. "Hyper-clean 3D render, ambient studio lighting, octane render, 8k resolution, minimalist Nate Herk aesthetic").
3. **Color Palette**: Palet warna presisi (e.g. "Emerald green (#10b981), dark charcoal slate (#0f172a), frosted glass accent").
4. **Aspect Ratio**: Tentukan rasio aspek (1:1 untuk icon, 16:9 untuk banner, 4:3 untuk mockup).

## Eksekusi via Subagent:
```json
{
  "TypeName": "image-generator",
  "Role": "Visual Designer",
  "Prompt": "Buatkan ilustrasi logo modern apotek berbentuk plus medis futuristik dengan gradasi emerald dan cyan."
}
```
