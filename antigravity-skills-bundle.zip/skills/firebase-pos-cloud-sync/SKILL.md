---
name: firebase-pos-cloud-sync
description: Mengintegrasikan Google Cloud Firestore ke aplikasi web kasir/POS untuk sinkronisasi multi-device real-time (onSnapshot), offline persistence, dan cadangan data otomatis dengan kuota gratis Spark Plan.
---

# Skill: Firebase POS Cloud Sync (Real-time Multi-Device)

Skill ini memungkinkan aplikasi kasir apotek terhubung ke Google Cloud Firestore secara gratis untuk sinkronisasi antar perangkat secara instan.

## 1. Arsitektur Data Firestore
- Koleksi `medicines`: Menyimpan data seluruh master obat, harga beli, harga jual, stok, dan tanggal kadaluarsa.
- Koleksi `transactions`: Menyimpan riwayat invoice nota penjualan kasir.
- Koleksi `settings`: Profil apotek, alamat, nomor SIPA, dan catatan kaki struk.

## 2. Fitur Kunci:
1. **Real-time Listener (`onSnapshot`)**:
   Setiap kali ada penjualan di kasir HP, layar di laptop kasir lain langsung otomatis terpotong stoknya dalam milidetik tanpa perlu me-refresh halaman.
2. **Offline Persistence**:
   `db.enablePersistence({ synchronizeTabs: true })` memungkinkan kasir tetap bisa bertransaksi meski internet tiba-tiba mati/terputus. Data akan otomatis disinkronkan ke cloud saat internet kembali online.
3. **Dual-write**:
   Data tersimpan di LocalStorage browser sekaligus disinkronkan ke Cloud Firestore.

## 3. Kuota Gratis Spark Plan:
- 50.000 read / hari
- 20.000 write / hari
- 1 GB data teks (cukup untuk ratusan ribu obat)
