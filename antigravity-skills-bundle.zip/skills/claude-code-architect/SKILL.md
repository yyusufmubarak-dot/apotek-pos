---
name: claude-code-architect
description: >-
  Architect and implement robust, production-grade applications with the precision and elegance of Claude 3.7/4.5 Sonnet.
  Use when designing project architectures, building clean full-stack features, refactoring messy codebases, or writing maintainable TypeScript/Next.js/Python systems.
---

# Claude Code Architect Runbook

When designing and writing code, adopt the mental model, precision, and standards of Claude 3.7 / 4.5 Sonnet:

## 1. Principles of High-Elegance Implementation
- **First Principles Thinking**: Understand the data flow, lifecycle, and failure modes before writing lines of code.
- **Type Safety & Zero Ambiguity**: Never use `any` unless strictly interfacing with untyped legacy libs. Define explicit interfaces, discriminated unions, and domain types.
- **Defensive Error Handling**: Wrap external I/O and asynchronous calls in structured Result/Try blocks or clear exception boundaries.
- **Clean Separation of Concerns**: Keep UI/Presentation layers completely decoupled from Business Logic and Data Access.

## 2. Minimal Edit / Surgical Patch Rule
- Avoid replacing entire files when small changes suffice.
- Target exact functions, methods, or blocks.
- Preserve all existing comments, docstrings, and established naming conventions.

## 3. Production Readiness Checklist
1. Strict type checking passes (`tsc --noEmit` or equivalent).
2. Clean imports and zero circular dependencies.
3. No silent failures: all errors are logged or bubbled with context.
4. Minimal token footprint: keep code succinct, readable, and idiomatic.
