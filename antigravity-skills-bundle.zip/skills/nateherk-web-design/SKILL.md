---
name: nateherk-web-design
description: Produces elite, production-grade modern web designs following the Nate Herk aesthetic: hyper-clean dark/light modes, micro-interactions, glassmorphism, responsive grid layouts, and typography hierarchy.
---

# Nate Herk Web Design System & Guidelines

## 1. Aesthetic DNA
- **Theme Palette**: Deep slate/charcoal foundations (`#090A0F`, `#12151E`) paired with subtle accent glow (`#38BDF8`, `#818CF8`, `#A855F7`).
- **Surface Elevation**: Layered cards with 1px border highlights (`rgba(255, 255, 255, 0.08)`), subtle backdrop blurs (`backdrop-blur-md`), and gentle ambient drop shadows (`box-shadow: 0 8px 32px rgba(0,0,0,0.3)`).
- **Typography Hierarchy**: Distinct, readable fonts (Geist, Inter, Plus Jakarta Sans, or Outfit). High contrast headings with muted, elegant subtext (`text-slate-400` / `text-zinc-400`).
- **Interactive Feedback**: Tactile micro-interactions on hover (scale `1.02`, smooth 200ms ease transitions, glowing border hover states).

## 2. Technical Stack Recommendation
- **Framework**: Next.js (App Router) or Vite + React / Modern HTML5 + Tailwind CSS.
- **Icons**: Lucide Icons or Tabler Icons.
- **Animation**: Framer Motion / Tailwind Transitions.

## 3. Implementation Rules
1. Never build boring, default white-box dashboards. Every view must feel polished, modern, and high-tech.
2. Ensure full accessibility: high color contrast ratio, semantic HTML tags, keyboard accessibility.
3. Mobile-First Responsiveness: Seamlessly adapt from phone viewports (390px) to ultra-wide displays.
