param(
    [string]$Url = "http://localhost:3000",
    [string]$OutputFile = "screenshot.png",
    [int]$WaitMs = 2000,
    [string]$WindowSize = "1280,850"
)

Start-Process 'msedge' -ArgumentList '--headless', "--virtual-time-budget=$WaitMs", "--screenshot=$OutputFile", "--window-size=$WindowSize", $Url -Wait
Write-Output "Screenshot berhasil disimpan ke: $OutputFile"
