---
name: headless-screenshot-capture
description: Otomatisasi pengambilan screenshot halaman web secara headless menggunakan Microsoft Edge / Google Chrome tanpa memerlukan instalasi library berat (Puppeteer/Playwright).
---

# Skill: Headless Screenshot Capture (Mengatur & Mengambil SS Otomatis)

Skill ini memungkinkan agen AI untuk secara mandiri mengambil screenshot berkualitas tinggi dari aplikasi web lokal (`file:///` atau `http://localhost`) maupun web publik.

## Cara Kerja
1. Memanfaatkan binary headless bawaan Windows/Linux (`msedge` atau `chrome`).
2. Menggunakan argumen `--headless`, `--virtual-time-budget=2000` (untuk memastikan script JS dan animasi selesai di-render), dan `--window-size=1280,850`.
3. Parameter `--screenshot=OUTPUT_PATH` menyimpan gambar secara instan ke disk.

## Contoh Perintah PowerShell
```powershell
Start-Process 'msedge' -ArgumentList '--headless', '--virtual-time-budget=2000', '--screenshot=C:\output\ss-view.png', '--window-size=1280,850', 'file:///C:/project/index.html' -Wait
```

## Tips Optimasi untuk Agen:
- Gunakan query parameters seperti `?test=modal` atau `?test=cart` untuk membuka state dialog/modal secara otomatis saat halaman dimuat sebelum screenshot diambil.
