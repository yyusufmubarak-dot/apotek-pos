#!/usr/bin/env python3
"""
Helper Script: Generate Video dengan Google Veo
Usage:
  python generate_veo_video.py --prompt "A futuristic flying car over neon Jakarta" --resolution 1080p --output video.mp4
"""

import argparse
import time
import os
import sys

def main():
    parser = argparse.ArgumentParser(description="Google Veo Video Generator")
    parser.add_argument("--prompt", required=True, help="Deskripsi video sinematik")
    parser.add_argument("--resolution", default="720p", choices=["720p", "1080p", "4k"], help="Resolusi video")
    parser.add_argument("--aspect_ratio", default="16:9", choices=["16:9", "9:16", "1:1"], help="Rasio aspek")
    parser.add_argument("--output", default="veo_generated_video.mp4", help="Nama file output")
    args = parser.parse_args()

    try:
        from google import genai
        from google.genai import types
    except ImportError:
        print("Error: Library 'google-genai' belum terpasang. Jalankan: pip install google-genai")
        sys.exit(1)

    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        print("Peringatan: Pastikan environment variable GEMINI_API_KEY sudah disetel.")

    client = genai.Client()
    print(f"🎬 Mengirim permintaan ke Google Veo 3.1: '{args.prompt}'...")

    operation = client.models.generate_videos(
        model="veo-3.1-generate-preview",
        prompt=args.prompt,
        config=types.GenerateVideosConfig(
            resolution=args.resolution,
            aspect_ratio=args.aspect_ratio
        )
    )

    print(f"⏳ Status: Menunggu proses rendering di server Google (Operation: {operation.name})...")
    while not operation.done:
        time.sleep(10)
        operation = client.operations.get(operation)
        print("  Masih memproses...")

    generated_video = operation.response.generated_videos[0]
    client.files.download(file=generated_video.video, destination=args.output)
    print(f"✅ Selesai! Video berhasil disimpan ke: {args.output}")

if __name__ == "__main__":
    main()
