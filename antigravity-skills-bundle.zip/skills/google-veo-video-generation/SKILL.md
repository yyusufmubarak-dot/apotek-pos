---
name: google-veo-video-generation
description: Menghasilkan video AI sinematik beresolusi tinggi (720p, 1080p, 4K) menggunakan model resmi Google Veo (Veo 3.1 & Veo 2) melalui Google GenAI SDK. Mendukung text-to-video, image-to-video, transisi frame, dan video extension.
---

# Skill: Google Veo - AI Video Generation (Veo 3.1 & Veo 2)

Google Veo adalah model kecerdasan buatan terdepan dari Google DeepMind yang dirancang khusus untuk menghasilkan video berkualitas tinggi, realistis, dan sinematik dengan pemahaman fisika dunia nyata serta perintah bahasa alami.

---

## 1. Kemampuan Utama Google Veo
1. **Text-to-Video**: Mengubah prompt deskripsi teks menjadi video dengan gerakan kamera sinematik.
2. **Image-to-Video (First Frame to Video)**: Mengambil gambar statis sebagai frame awal lalu menggerakkannya secara dinamis.
3. **First-and-Last Frame Interpolation**: Membuat video transisi mulus antara gambar awal dan gambar akhir.
4. **Video Extension**: Memperpanjang durasi video yang sudah ada secara kontinu.
5. **Kontrol Resolusi & Rasio Aspek**: Mendukung 720p, 1080p, hingga 4K, serta rasio aspek 16:9 (Landscape), 9:16 (Shorts/TikTok/Reels), dan 1:1.

---

## 2. Model yang Tersedia di Gemini API
- **`veo-3.1-generate-preview`**: Model flagship terbaik untuk video 720p, 1080p, dan 4K dengan fidelitas visual tertinggi.
- **`veo-3.1-fast-generate-preview`**: Model generasi video cepat dengan latensi rendah.
- **`veo-2.0-generate-001`**: Versi stabil Google Veo 2.
- **`gemini-omni-1.1-flash`**: Model multimodal untuk generative video editing dan turn-by-turn video conversation.

---

## 3. Implementasi Kode Resmi (Python `google-genai` SDK)

### A. Text to Video (Dasar)
```python
import time
from google import genai
from google.genai import types

client = genai.Client()

prompt = """
Cinematic aerial drone shot slowly descending over misty pine mountains at sunrise,
golden morning light piercing through fog, hyper-realistic, 4k, 24fps film aesthetic.
"""

operation = client.models.generate_videos(
    model="veo-3.1-generate-preview",
    prompt=prompt,
    config=types.GenerateVideosConfig(
        aspect_ratio="16:9",  # atau "9:16" untuk TikTok/Reels
        resolution="1080p",   # "720p", "1080p", "4k"
        duration_seconds=5
    ),
)

print(f"Operasi dimulai: {operation.name}. Menunggu video selesai dibuat...")

# Polling operasi hingga selesai
while not operation.done:
    time.sleep(10)
    operation = client.operations.get(operation)

# Download video hasil
generated_video = operation.response.generated_videos[0]
client.files.download(file=generated_video.video, destination="output_veo.mp4")
print("Video berhasil disimpan ke output_veo.mp4!")
```

### B. Image to Video (Menggerakkan Gambar)
```python
from google import genai
from google.genai import types
from PIL import Image

client = genai.Client()
ref_image = Image.open("input_photo.jpg")

operation = client.models.generate_videos(
    model="veo-3.1-generate-preview",
    prompt="Camera slowly orbits the subject, gentle wind blowing through hair and trees, cinematic lighting.",
    image=ref_image,
    config=types.GenerateVideosConfig(
        aspect_ratio="16:9",
        resolution="720p"
    ),
)
```

---

## 4. Formula Prompt Sinematik Google Veo
Untuk mendapatkan kualitas video setara film bioskop (*cinematic*):
1. **Camera Movement**: Sebutkan pergerakan kamera (*drone shot, slow push-in, orbital pan, tracking shot, low-angle tilt*).
2. **Subject & Action**: Jelaskan siapa/apa subjeknya dan gerakan fisiknya secara jelas.
3. **Lighting & Atmosphere**: Tentukan pencahayaan (*golden hour, neon cyberpunk haze, moody studio rim light, volumetric fog*).
4. **Style / Aesthetics**: Gunakan istilah fotografi (*35mm anamorphic lens, shallow depth of field, photorealistic, 4k, 24fps*).
