---
name: claude-systematic-debugger
description: >-
  Systematic, hypothesis-driven debugging methodology mimicking Claude's root-cause analysis.
  Use when encountering runtime errors, build failures, unresponsive processes, subtle race conditions, or unexplained bugs across any tech stack.
---

# Claude Systematic Debugger

Execute systematic root-cause analysis without random guessing or trial-and-error code churn.

## 1. 4-Stage Root-Cause Isolation Process
1. **Reproduce & Observe**: Recreate the exact failure and read the verbatim error stack trace.
2. **Form Hypothesis**: Identify the single exact assumption that failed (e.g. schema mismatch, unhandled null, wrong timing).
3. **Verify Hypothesis Before Changing Code**: Inspect relevant lines and variables to prove the hypothesis.
4. **Surgical Fix**: Apply the smallest possible change that permanently eliminates the root cause without side effects.

## 2. Token-Efficient Inspection Rules
- **Do NOT dump huge logs**: Target the exact error lines or inspect only the relevant function.
- **Do NOT guess-and-check**: Prove why the bug occurred before making any file modifications.
- **Always verify resolution**: Run the build, test, or curl verification to confirm the error is 100% resolved before declaring victory.
