---
name: claude-opus-coder
description: Claude Opus 5.5 grade autonomous programming, surgical code diffs, zero hallucination, and prompt cache prefix optimization.
---

# Claude Opus 5.5 Coding & Prompt Cache Optimization

## 1. Prompt Cache Optimization (Cost & Speed Efficiency)
- **Static Prefix Invariance**: Keep system prompts, framework rules, design tokens, and core schema strictly at the very top of context. Never inject dynamic variables (like timestamps or variable counters) before static instructions.
- **Hierarchical Context Ordering**:
  1. System Rules & Personas (Always Cached)
  2. Skill & API Tool Definitions (Always Cached)
  3. Stable Workspace Schemas / Types (Cached across turns)
  4. Dynamic User Prompts & Volatile Logs (Appended at the tail)
- **Token Trimming**: Provide exact, targeted code replacements. Never re-print unmodified 500-line files.

## 2. Claude Opus 5.5 Coding Rigor
- **Architecture**: Clean architecture, clear domain boundaries, separation of concerns.
- **Defensive Engineering**: Explicit error handling, null safety, resource disposal, comprehensive type contracts.
- **Surgical Execution**: Identify root causes before writing code; apply minimal, high-leverage modifications.
