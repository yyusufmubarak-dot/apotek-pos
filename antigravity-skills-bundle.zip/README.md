# Antigravity Skills Bundle
Kumpulan skill resmi, kustomisasi, dan panduan arsitektur agen otonom Google Antigravity.

## Daftar Skill yang Termasuk dalam Bundle Ini:

| Kategori | Nama Skill | Deskripsi |
| :--- | :--- | :--- |
| **Visual & Media** | `headless-screenshot-capture` | Mengatur dan mengambil screenshot web otomatis secara headless tanpa browser GUI. |
| **Visual & Media** | `image-generation` | Menghasilkan gambar, logo, dan konsep desain via prompting & subagent. |
| **Visual & Media** | `gemini-omni-flash-video` | Generative video editing, frame-to-video, dan transisi video via Gemini Omni Flash. |
| **Frontend & UI** | `nateherk-web-design` | Standar desain web modern "Anti-Slop", glassmorphism, dan hierarki tipografi. |
| **Frontend & UI** | `generative_ui` | Merender widget interaktif HTML inline dalam chat atau canvas mandiri. |
| **Engineering** | `claude-opus-coder` | Standar pemrograman otonom, diff bedah presisi, dan zero hallucination. |
| **Engineering** | `claude-code-architect` | Merancang arsitektur sistem skala besar, full-stack Next.js, TypeScript, dan Python. |
| **Engineering** | `claude-systematic-debugger`| Metodologi debugging hipotesis terstruktur untuk lacak root cause bug rumit. |
| **Core AI SDK** | `google-antigravity-sdk` | Panduan membuat dan mengorkestrasi sistem agen otonom multi-agent. |
| **Core AI SDK** | `gemini-api-dev` | Panggilan Gemini API multimodal, function calling, dan structured output. |
| **Core AI SDK** | `gemini-live-api-dev` | Streaming audio/video dua arah secara real-time via WebSocket. |
| **Platform AGY** | `agy-customizations` | Arsitektur kustomisasi Antigravity (skills, rules, MCP, hooks, plugins). |
| **Platform AGY** | `antigravity-guide` | Panduan lengkap platform Antigravity, CLI, keybindings, dan IDE. |

## Cara Menggunakan Skill Ini:
Salin folder skill yang diinginkan ke direktori kustomisasi Anda:
- Windows: `%USERPROFILE%\.gemini\antigravity\skills\`
- Linux/macOS: `~/.gemini/antigravity/skills/`
