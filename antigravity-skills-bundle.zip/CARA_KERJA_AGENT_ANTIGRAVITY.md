# Cara Kerja & Arsitektur Internal Agen Antigravity
Dokumentasi internal: Bagaimana agen AI Antigravity diprogram, berpikir, dan mengeksekusi tugas.

---

## 1. Siklus ReAct (Reasoning + Acting)
Setiap permintaan pengguna tidak langsung dijawab dengan teks semata. Agen bekerja melalui loop otonom:
1. **Thought (Analisis Masalah)**: Agen menalar langkah-langkah yang diperlukan, memeriksa batasan aturan pengguna (*User Rules*), dan merumuskan rencana aksi.
2. **Action (Pemanggilan Alat / Tool Calling)**:
   - `run_command`: Menjalankan PowerShell/Bash untuk kompilasi, build, atau eksekusi proses background.
   - `write_file` / `edit_file`: Membuat atau melakukan modifikasi kode secara bedah (*surgical edits*).
   - `read_file`: Membaca bagian file secara spesifik (tail/offset) untuk menghemat context window.
   - `manage_task`: Memantau dan mengontrol proses latar belakang tanpa polling berulang (*reactive wakeup*).
3. **Observation (Hasil Eksekusi Alat)**: Agen membaca keluaran stdout/stderr alat untuk memverifikasi apakah langkah berhasil atau error.
4. **Final Response**: Memberikan ringkasan padat dan dapat ditindaklanjuti kepada pengguna.

---

## 2. Struktur Skill di Antigravity
Skill adalah modul instruksi khusus yang dapat dimuat secara dinamis saat tugas tertentu dijalankan:
- Setiap skill memiliki berkas utama `SKILL.md` dengan frontmatter YAML:
  ```yaml
  ---
  name: nama-skill
  description: Kapan dan bagaimana skill ini digunakan
  ---
  ```
- Sub-direktori opsional:
  - `scripts/`: Skrip pembantu (PowerShell, Python, Bash).
  - `examples/`: Contoh implementasi.
  - `references/`: Dokumentasi rujukan tambahan.

---

## 3. Sistem Artifacts & Pelaporan Visual
Untuk menampilkan laporan terstruktur, screenshot, atau diagram arsitektur:
- Agen menulis dokumen Markdown ke folder `brain/<conversation-id>/`.
- Dilengkapi diagram Mermaid (`flowchart`, `sequenceDiagram`) dan KaTeX Math.
- Menyematkan gambar atau tangkapan layar langsung menggunakan protokol `![alt](file:///path)`.

---

## 4. Filosofi Desain "Anti-Slop" (Nate Herk Aesthetic)
Agen diprogram untuk menolak template web bawaan AI yang generik ("AI Slop"):
- **Fondasi Warna**: Deep charcoal / slate palette (`#090A0F`, `#0f172a`) dipadukan dengan aksen glow berpendar (`#10b981`, `#06b6d4`).
- **Elevasi & Glassmorphism**: Kartu bertingkat dengan border halus 1px (`rgba(255,255,255,0.08)`), backdrop blur (`backdrop-blur-md`), dan bayangan ambien.
- **Tipografi Presisi**: Hierarki font tegas (*Plus Jakarta Sans* untuk UI, *JetBrains Mono* untuk data angka, barcode, dan invoice).
- **Mikro-Interaksi Taktil**: Efek hover interaktif, laser scanner reticle HUD, dan feedback audio sintetis Web Audio API.
